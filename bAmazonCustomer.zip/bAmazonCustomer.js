var mysql = require("mysql");
var inquirer = require("inquirer");

var connection = mysql.createConnection({
  host: "localhost",
  port: 3306,

  // Your username
  user: "root",

  // Your password
  password: "picklem88",
  database: "bamazon"
});

connection.connect(function(err) {
  if (err) throw err;
  //console.log("con attempt",connection);
  //displayProducts();
  start();
});



function start() {
    inquirer
      .prompt([
        {
        name: "productID", 
        type: "input",  //this is an input field for the user OR I could do list and then add the options afterwards
        message: "Please select item by 'ID'"              
        },     
            //move the below to the function for artist or favorite songe etc. 
        {
        name: "productQuantity", 
        type: "input",  //this is an input field for the user OR I could do list and then add the options afterwards
        message: "How many of the item would you like?",
        }
        ])
    
        .then(function(answer) {
           var match = quantityCheck(answer.productID) //this is taking the quantity function below and passing the 'productID' the user entered, which in the last case was a value of '1' - if I changed this to "productQuantity" it would pass the 2nd input the user puts in.  
            console.log("match", match);
            console.log("ans.id", answer.productID);
             //console.log("match", matchedItem);
            
            console.log("ans.q", answer.productQuantity);
            console.log("answer", answer);
            
        });

    };

//--------------------------------------------------//
function quantityCheck(name) { 
    connection.query("SELECT id, product_name, price, quantity FROM products WHERE id = ?",[name],function(err, res) {
        
        console.log("-----------------------------------");
        console.log("response", res);
        console.log(res[0].quantity);
        console.log("name:", name);
        var itemQuantity = res[0].quantity;
        console.log("item Quantity:", itemQuantity);
       
       
        //console.log("productQuantity", productQuantity);

        // if(10 > itemQuantity){
        //     console.log("Yea we can help");
            
        //  } else {
        //      console.log("insufficient Quantity");
        //     // console.log("itemPQ", productQuantity);
        // }
        
        connection.end();
    });
}

//--------------------------------------------------//
function displayProducts() {
    var query = "SELECT id, product_name, price FROM products";
    connection.query(query, function(err, res) {
      if (err) throw err;
      console.log(res);
      });
      //start();
      
}

